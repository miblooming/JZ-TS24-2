# FlyingBearPlugin
Cura plugin which enables printing directly to the FlyingBear 3d printer be equipped with JZ-TS LCD and monitoring the progress
Manager your FlyingBear printers via WIFI

