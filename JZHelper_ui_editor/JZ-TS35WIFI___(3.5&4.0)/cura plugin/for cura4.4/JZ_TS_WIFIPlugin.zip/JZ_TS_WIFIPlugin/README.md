# JZ_TS_WIFIPlugin
Manager your printer be equipped with JZ-TS LCD via WIFI

* Manually:
  - Make sure your Cura version is 4.0 or newer
  - Download or clone the repository into [Cura installation folder]/plugins/JZ_TS_WIFIPlugin
    or in the plugins folder inside the configuration folder. The configuration folder can be
    found via Help -> Show Configuration Folder inside Cura.

