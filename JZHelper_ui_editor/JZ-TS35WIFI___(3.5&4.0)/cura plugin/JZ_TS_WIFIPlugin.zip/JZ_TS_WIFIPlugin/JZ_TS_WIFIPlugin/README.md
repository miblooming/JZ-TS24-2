# JZ_TS_WIFIPlugin
Manager your printer be equipped with JZ-TS LCD via WIFI

